CREATE TABLE [SM_InsightHit_Month] (
		[InsightHitID]             [int] IDENTITY(1, 1) NOT NULL,
		[InsightHitPeriodFrom]     [datetime2](7) NOT NULL,
		[InsightHitPeriodTo]       [datetime2](7) NOT NULL,
		[InsightHitValue]          [bigint] NOT NULL,
		[InsightHitInsightID]      [int] NOT NULL
) 
ALTER TABLE [SM_InsightHit_Month]
	ADD
	CONSTRAINT [PK_SM_InsightHit_Month]
	PRIMARY KEY
	CLUSTERED
	([InsightHitID])
	
CREATE UNIQUE NONCLUSTERED INDEX [UQ_SM_InsightHit_Month_InsightHitInsightID_InsightHitPeriodFrom_InsightHitPeriodTo]
	ON [SM_InsightHit_Month] ([InsightHitInsightID], [InsightHitPeriodFrom], [InsightHitPeriodTo])
	
ALTER TABLE [SM_InsightHit_Month]
	WITH CHECK
	ADD CONSTRAINT [FK_SM_InsightHit_Month_SM_Insight_InsightHitInsightID]
	FOREIGN KEY ([InsightHitInsightID]) REFERENCES [SM_Insight] ([InsightID])
ALTER TABLE [SM_InsightHit_Month]
	CHECK CONSTRAINT [FK_SM_InsightHit_Month_SM_Insight_InsightHitInsightID]
