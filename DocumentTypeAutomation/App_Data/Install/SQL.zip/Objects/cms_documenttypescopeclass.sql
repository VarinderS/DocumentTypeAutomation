CREATE TABLE [CMS_DocumentTypeScopeClass] (
		[ScopeID]     [int] NOT NULL,
		[ClassID]     [int] NOT NULL
) 
ALTER TABLE [CMS_DocumentTypeScopeClass]
	ADD
	CONSTRAINT [PK_CMS_DocumentTypeScopeClass]
	PRIMARY KEY
	CLUSTERED
	([ScopeID], [ClassID])
	
CREATE NONCLUSTERED INDEX [IX_CMS_DocumentTypeScopeClass_ClassID]
	ON [CMS_DocumentTypeScopeClass] ([ClassID]) 

ALTER TABLE [CMS_DocumentTypeScopeClass]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_DocumentTypeScopeClass_ClassID_CMS_Class]
	FOREIGN KEY ([ClassID]) REFERENCES [CMS_Class] ([ClassID])
ALTER TABLE [CMS_DocumentTypeScopeClass]
	CHECK CONSTRAINT [FK_CMS_DocumentTypeScopeClass_ClassID_CMS_Class]
ALTER TABLE [CMS_DocumentTypeScopeClass]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_DocumentTypeScopeClass_ScopeID_CMS_DocumentTypeScope]
	FOREIGN KEY ([ScopeID]) REFERENCES [CMS_DocumentTypeScope] ([ScopeID])
ALTER TABLE [CMS_DocumentTypeScopeClass]
	CHECK CONSTRAINT [FK_CMS_DocumentTypeScopeClass_ScopeID_CMS_DocumentTypeScope]
