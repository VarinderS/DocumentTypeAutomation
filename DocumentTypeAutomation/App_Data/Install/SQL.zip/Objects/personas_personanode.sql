CREATE TABLE [Personas_PersonaNode] (
		[PersonaID]     [int] NOT NULL,
		[NodeID]        [int] NOT NULL
) 
ALTER TABLE [Personas_PersonaNode]
	ADD
	CONSTRAINT [PK_Personas_PersonaNode]
	PRIMARY KEY
	CLUSTERED
	([PersonaID], [NodeID])
	
CREATE NONCLUSTERED INDEX [IX_Personas_PersonaNode_NodeID]
	ON [Personas_PersonaNode] ([NodeID]) 
CREATE NONCLUSTERED INDEX [IX_Personas_PersonaNode_PersonaID]
	ON [Personas_PersonaNode] ([PersonaID]) 

ALTER TABLE [Personas_PersonaNode]
	WITH CHECK
	ADD CONSTRAINT [FK_Personas_PersonaNode_CMS_Tree]
	FOREIGN KEY ([NodeID]) REFERENCES [CMS_Tree] ([NodeID])
ALTER TABLE [Personas_PersonaNode]
	CHECK CONSTRAINT [FK_Personas_PersonaNode_CMS_Tree]
