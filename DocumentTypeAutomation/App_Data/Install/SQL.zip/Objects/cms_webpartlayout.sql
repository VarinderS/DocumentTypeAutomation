CREATE TABLE [CMS_WebPartLayout] (
		[WebPartLayoutID]               [int] IDENTITY(1, 1) NOT NULL,
		[WebPartLayoutCodeName]         [nvarchar](200) NOT NULL,
		[WebPartLayoutDisplayName]      [nvarchar](200) NOT NULL,
		[WebPartLayoutDescription]      [nvarchar](max) NULL,
		[WebPartLayoutCode]             [nvarchar](max) NULL,
		[WebPartLayoutVersionGUID]      [nvarchar](100) NULL,
		[WebPartLayoutWebPartID]        [int] NOT NULL,
		[WebPartLayoutGUID]             [uniqueidentifier] NOT NULL,
		[WebPartLayoutLastModified]     [datetime2](7) NOT NULL,
		[WebPartLayoutCSS]              [nvarchar](max) NULL,
		[WebPartLayoutIsDefault]        [bit] NULL
)  
ALTER TABLE [CMS_WebPartLayout]
	ADD
	CONSTRAINT [PK_CMS_WebPartLayout]
	PRIMARY KEY
	NONCLUSTERED
	([WebPartLayoutID])
	
ALTER TABLE [CMS_WebPartLayout]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPartLayout_WebPartLayoutCodeName]
	DEFAULT ('') FOR [WebPartLayoutCodeName]
ALTER TABLE [CMS_WebPartLayout]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPartLayout_WebPartLayoutDisplayName]
	DEFAULT ('') FOR [WebPartLayoutDisplayName]
CREATE NONCLUSTERED INDEX [IX_CMS_WebPartLayout_WebPartLayoutWebPartID]
	ON [CMS_WebPartLayout] ([WebPartLayoutWebPartID]) 
CREATE CLUSTERED INDEX [IX_CMS_WebPartLayout_WebPartLayoutWebPartID_WebPartLayoutCodeName]
	ON [CMS_WebPartLayout] ([WebPartLayoutWebPartID], [WebPartLayoutCodeName]) 

ALTER TABLE [CMS_WebPartLayout]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_WebPartLayout_WebPartLayoutWebPartID_CMS_WebPart]
	FOREIGN KEY ([WebPartLayoutWebPartID]) REFERENCES [CMS_WebPart] ([WebPartID])
ALTER TABLE [CMS_WebPartLayout]
	CHECK CONSTRAINT [FK_CMS_WebPartLayout_WebPartLayoutWebPartID_CMS_WebPart]
