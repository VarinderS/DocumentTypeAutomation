CREATE TABLE [CMS_RelationshipName] (
		[RelationshipNameID]             [int] IDENTITY(1, 1) NOT NULL,
		[RelationshipDisplayName]        [nvarchar](200) NOT NULL,
		[RelationshipName]               [nvarchar](200) NOT NULL,
		[RelationshipAllowedObjects]     [nvarchar](450) NULL,
		[RelationshipGUID]               [uniqueidentifier] NOT NULL,
		[RelationshipLastModified]       [datetime2](7) NOT NULL
) 
ALTER TABLE [CMS_RelationshipName]
	ADD
	CONSTRAINT [PK_CMS_RelationshipName]
	PRIMARY KEY
	CLUSTERED
	([RelationshipNameID])
	
ALTER TABLE [CMS_RelationshipName]
	ADD
	CONSTRAINT [DEFAULT_CMS_RelationshipName_RelationshipDisplayName]
	DEFAULT ('') FOR [RelationshipDisplayName]
ALTER TABLE [CMS_RelationshipName]
	ADD
	CONSTRAINT [DEFAULT_CMS_RelationshipName_RelationshipGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [RelationshipGUID]
ALTER TABLE [CMS_RelationshipName]
	ADD
	CONSTRAINT [DEFAULT_CMS_RelationshipName_RelationshipName]
	DEFAULT ('') FOR [RelationshipName]
CREATE NONCLUSTERED INDEX [IX_CMS_RelationshipName_RelationshipAllowedObjects]
	ON [CMS_RelationshipName] ([RelationshipAllowedObjects]) 
CREATE NONCLUSTERED INDEX [IX_CMS_RelationshipName_RelationshipName_RelationshipDisplayName]
	ON [CMS_RelationshipName] ([RelationshipName], [RelationshipDisplayName]) 

