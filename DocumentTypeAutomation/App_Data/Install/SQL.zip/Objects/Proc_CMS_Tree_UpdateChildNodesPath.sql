CREATE PROCEDURE [Proc_CMS_Tree_UpdateChildNodesPath]
	@OldAliasPath nvarchar(450), 
    @NewAliasPath nvarchar(450),
    @OldSiteID int, 
    @NewSiteID int,
    @NodeLevelChange int,
	@GenerateAliases bit
AS
BEGIN
	-- Generate aliases for the child nodes
	IF @GenerateAliases = 1
	BEGIN
		-- There is no need to generate aliases if the document was moved to the same location (even between sites)
		IF @OldAliasPath <> @NewAliasPath
		BEGIN
			INSERT INTO CMS_DocumentAlias ([AliasNodeID], [AliasCulture], [AliasURLPath], [AliasExtensions], [AliasCampaign], [AliasWildcardRule], [AliasPriority], [AliasGUID], [AliasLastModified], [AliasSiteID] )
				SELECT D.NodeID, NULL, D.NodeAliasPath, D.DocumentExtensions,'', '', 1, NEWID(), GETDATE(), @NewSiteID
					FROM
					(SELECT DISTINCT NodeID, NodeAliasPath, DocumentExtensions	FROM View_CMS_Tree_Joined
						WHERE NodeAliasPath LIKE @OldAliasPath + '/%' AND NodeSiteID = @OldSiteID 
						AND NOT EXISTS (SELECT AliasID 
										FROM CMS_DocumentAlias 
										WHERE AliasNodeID = View_CMS_Tree_Joined.NodeID AND AliasURLPath = View_CMS_Tree_Joined.NodeAliasPath 
										AND ISNULL(AliasExtensions, '') = ISNULL(DocumentExtensions, ''))) AS D
		END
	END
	
	-- Update the child nodes path, site and level
	UPDATE CMS_Tree 
		SET NodeAliasPath = @NewAliasPath + right(NodeAliasPath, LEN(NodeAliasPath) - LEN(@OldAliasPath)), 
			NodeSiteID = @NewSiteID,
			NodeLevel = NodeLevel + @NodeLevelChange
		WHERE NodeSiteID = @OldSiteID AND NodeAliasPath LIKE @OldAliasPath + '/%'
END
