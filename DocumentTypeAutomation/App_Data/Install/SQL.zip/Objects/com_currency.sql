CREATE TABLE [COM_Currency] (
		[CurrencyID]               [int] IDENTITY(1, 1) NOT NULL,
		[CurrencyName]             [nvarchar](200) NOT NULL,
		[CurrencyDisplayName]      [nvarchar](200) NOT NULL,
		[CurrencyCode]             [nvarchar](200) NOT NULL,
		[CurrencyRoundTo]          [int] NULL,
		[CurrencyEnabled]          [bit] NOT NULL,
		[CurrencyFormatString]     [nvarchar](200) NOT NULL,
		[CurrencyIsMain]           [bit] NOT NULL,
		[CurrencyGUID]             [uniqueidentifier] NULL,
		[CurrencyLastModified]     [datetime2](7) NOT NULL,
		[CurrencySiteID]           [int] NULL
) 
ALTER TABLE [COM_Currency]
	ADD
	CONSTRAINT [PK_COM_Currency]
	PRIMARY KEY
	NONCLUSTERED
	([CurrencyID])
	
ALTER TABLE [COM_Currency]
	ADD
	CONSTRAINT [DEFAULT_COM_Currency_CurrencyCode]
	DEFAULT (N'') FOR [CurrencyCode]
ALTER TABLE [COM_Currency]
	ADD
	CONSTRAINT [DEFAULT_COM_Currency_CurrencyDisplayName]
	DEFAULT (N'') FOR [CurrencyDisplayName]
ALTER TABLE [COM_Currency]
	ADD
	CONSTRAINT [DEFAULT_COM_Currency_CurrencyFormatString]
	DEFAULT (N'') FOR [CurrencyFormatString]
ALTER TABLE [COM_Currency]
	ADD
	CONSTRAINT [DEFAULT_COM_Currency_CurrencyName]
	DEFAULT (N'') FOR [CurrencyName]
CREATE CLUSTERED INDEX [IX_COM_Currency_CurrencyDisplayName]
	ON [COM_Currency] ([CurrencyDisplayName]) 
CREATE NONCLUSTERED INDEX [IX_COM_Currency_CurrencyEnabled_CurrencyIsMain]
	ON [COM_Currency] ([CurrencyEnabled], [CurrencyIsMain])
	
CREATE NONCLUSTERED INDEX [IX_COM_Currency_CurrencySiteID]
	ON [COM_Currency] ([CurrencySiteID]) 

ALTER TABLE [COM_Currency]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_Currency_CurrencySiteID_CMS_Site]
	FOREIGN KEY ([CurrencySiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_Currency]
	CHECK CONSTRAINT [FK_COM_Currency_CurrencySiteID_CMS_Site]
