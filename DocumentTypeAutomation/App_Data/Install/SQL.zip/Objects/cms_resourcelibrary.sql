CREATE TABLE [CMS_ResourceLibrary] (
		[ResourceLibraryID]             [int] IDENTITY(1, 1) NOT NULL,
		[ResourceLibraryResourceID]     [int] NOT NULL,
		[ResourceLibraryPath]           [nvarchar](200) NOT NULL
) 
ALTER TABLE [CMS_ResourceLibrary]
	ADD
	CONSTRAINT [PK_CMS_ResourceLibrary]
	PRIMARY KEY
	CLUSTERED
	([ResourceLibraryID])
	
ALTER TABLE [CMS_ResourceLibrary]
	ADD
	CONSTRAINT [DEFAULT_CMS_ResourceLibrary_ResourceLibraryPath]
	DEFAULT (N'') FOR [ResourceLibraryPath]
ALTER TABLE [CMS_ResourceLibrary]
	ADD
	CONSTRAINT [DEFAULT_CMS_ResourceLibrary_ResourceLibraryResourceID]
	DEFAULT ((0)) FOR [ResourceLibraryResourceID]
CREATE NONCLUSTERED INDEX [IX_CMS_ResourceLibrary]
	ON [CMS_ResourceLibrary] ([ResourceLibraryResourceID]) 

ALTER TABLE [CMS_ResourceLibrary]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_ResourceLibrary_CMS_Resource]
	FOREIGN KEY ([ResourceLibraryResourceID]) REFERENCES [CMS_Resource] ([ResourceID])
ALTER TABLE [CMS_ResourceLibrary]
	CHECK CONSTRAINT [FK_CMS_ResourceLibrary_CMS_Resource]
