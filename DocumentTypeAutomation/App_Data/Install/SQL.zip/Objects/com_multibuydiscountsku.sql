CREATE TABLE [COM_MultiBuyDiscountSKU] (
		[MultiBuyDiscountID]     [int] NOT NULL,
		[SKUID]                  [int] NOT NULL
) 
ALTER TABLE [COM_MultiBuyDiscountSKU]
	ADD
	CONSTRAINT [PK_COM_MultiBuyDiscountSKU]
	PRIMARY KEY
	CLUSTERED
	([MultiBuyDiscountID], [SKUID])
	
ALTER TABLE [COM_MultiBuyDiscountSKU]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscountSKU_SKUID]
	DEFAULT ((0)) FOR [SKUID]
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscountSKU_SKUID]
	ON [COM_MultiBuyDiscountSKU] ([SKUID]) 

ALTER TABLE [COM_MultiBuyDiscountSKU]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscountSKU_MultiBuyDiscountID_COM_MultiBuyDiscount]
	FOREIGN KEY ([MultiBuyDiscountID]) REFERENCES [COM_MultiBuyDiscount] ([MultiBuyDiscountID])
ALTER TABLE [COM_MultiBuyDiscountSKU]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscountSKU_MultiBuyDiscountID_COM_MultiBuyDiscount]
ALTER TABLE [COM_MultiBuyDiscountSKU]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscountSKU_SKUID_COM_SKU]
	FOREIGN KEY ([SKUID]) REFERENCES [COM_SKU] ([SKUID])
ALTER TABLE [COM_MultiBuyDiscountSKU]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscountSKU_SKUID_COM_SKU]
