CREATE TABLE [CMS_ResourceTranslation] (
		[TranslationID]            [int] IDENTITY(1, 1) NOT NULL,
		[TranslationStringID]      [int] NOT NULL,
		[TranslationText]          [nvarchar](max) NULL,
		[TranslationCultureID]     [int] NOT NULL
)  
ALTER TABLE [CMS_ResourceTranslation]
	ADD
	CONSTRAINT [PK_CMS_ResourceTranslation]
	PRIMARY KEY
	CLUSTERED
	([TranslationID])
	
CREATE NONCLUSTERED INDEX [IX_CMS_ResourceTranslation_TranslationCultureID]
	ON [CMS_ResourceTranslation] ([TranslationCultureID]) 
CREATE NONCLUSTERED INDEX [IX_CMS_ResourceTranslation_TranslationStringID]
	ON [CMS_ResourceTranslation] ([TranslationStringID]) 

ALTER TABLE [CMS_ResourceTranslation]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_ResourceTranslation_TranslationCultureID_CMS_Culture]
	FOREIGN KEY ([TranslationCultureID]) REFERENCES [CMS_Culture] ([CultureID])
ALTER TABLE [CMS_ResourceTranslation]
	CHECK CONSTRAINT [FK_CMS_ResourceTranslation_TranslationCultureID_CMS_Culture]
ALTER TABLE [CMS_ResourceTranslation]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_ResourceTranslation_TranslationStringID_CMS_ResourceString]
	FOREIGN KEY ([TranslationStringID]) REFERENCES [CMS_ResourceString] ([StringID])
ALTER TABLE [CMS_ResourceTranslation]
	CHECK CONSTRAINT [FK_CMS_ResourceTranslation_TranslationStringID_CMS_ResourceString]
